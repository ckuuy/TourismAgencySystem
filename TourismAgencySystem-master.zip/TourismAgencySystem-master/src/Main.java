
import com.tourismAgencySystem.model.User;
import com.tourismAgencySystem.view.*;

import java.util.ArrayList;

public class Main {
    private User user;
    public static void main(String[] args) {
        System.out.println("Hello world!");
        //SearchRoomGUI searchRoomGUI = new SearchRoomGUI(new User());
        LoginGUI loginGUI = new LoginGUI();
        //HotelAddGUI hotelAddGUI = new HotelAddGUI();
        //RoomGUI roomGUI = new RoomGUI();
        //RoomAddGUI roomAddGUI = new RoomAddGUI();
        //SearchOutputGUI searchOutputGUI = new SearchOutputGUI();
        //RezCompleteGUI rezCompleteGUI = new RezCompleteGUI();
    }
}