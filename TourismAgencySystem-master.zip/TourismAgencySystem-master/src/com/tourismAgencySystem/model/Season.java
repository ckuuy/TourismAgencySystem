package com.tourismAgencySystem.model;

public class Season {
}
